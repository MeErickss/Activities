import discord
from discord import app_commands
from discord.ext import commands
import random


bot = commands.Bot(command_prefix="!", intents = discord.Intents.all())
client = discord.Client(intents=discord.Intents.default())

agenda=[]
sad_words=["UTFPR", "depressao", "manco", "triste", "raiva", "ansioso", "desanimado", "desisto", "nao sabo", "medo", "lazarento", "corno"]
starter_encouragements=["Vai ficar tudo bem", "Confio em vc <3", "Se acalme", "Vai dar tudo certo", "Vai passar", "Isso vai se resolver"]

@bot.event
async def on_ready():
    print(f"LOGADO")
    try:
        synced = await bot.tree.sync()
        print(f"Synced {len(synced)} command(s)")
    except Exception as e:
        print(e)

@bot.event
async def on_message(message):
    if message.author == client.user:
        return
    if message.content.startswith('Você sabo sabedor?'):
        await message.channel.send('Eu sabo')

    if any(word in message.content for word in sad_words):
        await message.channel.send(random.choice(starter_encouragements))

@bot.tree.command(name="adicionaraagenda")
@app_commands.describe(dia = "Digite o dia", mes = "Digite o mês", ano = "Digite o ano", tipoatvidade = "Ex: Prova, Trab etc", nomeatividade = "Digite o nome da atividade")
async def adicionaraagenda(interaction: discord.Interaction, dia: int, mes: int, ano: int,  tipoatvidade: str,nomeatividade: str):
    agenda.append([dia,mes,ano,tipoatvidade,nomeatividade])
    await interaction.response.send_message(f"{tipoatvidade} {nomeatividade}, adicionada com sucesso a data: {dia,mes,ano}")

@bot.tree.command(name="mostraragenda")
async def mostrar_agenda(interaction: discord.Interaction):
    await interaction.response.send_message(f"AGENDA: {agenda}")

@bot.tree.command(name="removerpordata")
@app_commands.describe(dia = "Digite o dia", mes = "Digite o mês", ano = "Digite o ano")
async def remover_por_data(interaction: discord.Interaction, dia: int, mes: int, ano: int):
    for i in range(len(agenda)):
        if dia in agenda[i] and mes in agenda[i] and ano in agenda[i]:
            await interaction.response.send_message(f"Tarefa do {dia}/{mes}/{ano}: {agenda[i]} removida")
            agenda.remove(agenda[i])

@bot.tree.command(name="removerpornometarefa")
@app_commands.describe(tipoatividade="Ex: Prova, Trab etc", nomeatvidade="Digite o nome da atividade")
async def remover_por_tarefa(interaction: discord.Interaction, tipoatividade: str ,nomeatvidade: str):
    for i in range(len(agenda)):
        if nomeatvidade in agenda[i]:
            await interaction.response.send_message(f"{tipoatividade,nomeatvidade}: {agenda[i]} removida")
            agenda.remove(agenda[i])

@bot.tree.command(name="procurarpordata")
@app_commands.describe(dia = "Digite o dia", mes = "Digite o mês", ano = "Digite o ano")
async def procurar_por_data(interaction: discord.Interaction, dia: int, mes: int, ano: int):
    for i in range(len(agenda)):
        if dia in agenda[i] and mes in agenda[i] and ano in agenda[i]:
            await interaction.response.send_message(f"Tarefa da data {dia}/{mes}/{ano}: {agenda[i]}")

@bot.tree.command(name="procurarpornometarefa")
@app_commands.describe(tipoatividade="Ex: Prova, Trab etc", nomeatvidade="Digite o nome da atividade")
async def procurar_por_nome_tarefa(interaction: discord.Interaction, tipoatividade: str ,nomeatvidade: str):
    for i in range(len(agenda)):
        if nomeatvidade in agenda[i]:
            await interaction.response.send_message(f"{tipoatividade,nomeatvidade}: {agenda[i]}")

@bot.tree.command(name="resetaragenda")
@app_commands.describe(confirmacao="Você tem certeza que deseja reiniciar a agenda? S/N")
async def resetaragenda(interaction: discord.Interaction, confirmacao: str):
    if confirmacao.lower() == 'sim' or confirmacao.lower() == 'ss' or confirmacao.lower() == 's':
        agenda=[]
    else:
        await interaction.response.send_message(f"Processo cancelado")


bot.run('TOKEN')