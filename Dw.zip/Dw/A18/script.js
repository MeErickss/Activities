function calcular(){
    let vmaxi = document.getElementById("vmax").value
    let vveiculo =  document.getElementById("vveic").value
    let divResultado = document.getElementById("resultado")
    let resultado = (vveiculo/vmaxi) - 1
    resultado = +(resultado.toFixed(1))
    let preco = 880.41

    if (resultado <= 0.2){
        preco = 130.16
    }

    if (resultado <= 0.2){
        preco = 195.23
    }

    divResultado.innerHTML = "<p> <strong>Você excedeu " + resultado*100 + "% a velocidade máxima. Sua multa é de R$" + preco + "</strong></p>"

}