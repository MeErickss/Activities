function calcular(){
    let nome = document.getElementById("name").value
    let altura = document.getElementById("altu").value
    let peso = document.getElementById("peso").value
    let divResultado = document.getElementById("resultado")
    let IMC = peso/(altura*altura)
    IMC = +(IMC.toFixed(1))
    let condicao

    if (IMC < 18.5){
        condicao = ("Magreza");
    }
    
    if (IMC > 18.5 && IMC < 24.9){
        condicao = ("Normal. Parabens!!!");
    }

    if (IMC > 25 && IMC < 29.9){
        condicao = "Sobrepeso.";
    }

    if (IMC > 30 && IMC < 34.9){
        condicao = ("Obesidade grau I.");
    }

    if (IMC > 35 && IMC < 39.9){
        condicao = ("Obesidade grau II.");
    }

    if (IMC > 40){
        condicao = ("Obesidade grau III.");
    }

    divResultado.innerHTML = "<p>" + nome + " seu IMC é " + IMC + " e você está com peso " + condicao + "</p>"
}