function Ex1(){
    let divResultado = document.getElementById('resultadof')
    divResultado.innerHTML = "<div id='div1'><h1>Ex01</h1><label for='num'>Digite um número: </label><input type='number' id='num'><button onclick='Calcular()'>Calcular</button><div id='resultado1'></div></div><script src='script.js'></script>"
}

function Ex2(){
    let divResultado = document.getElementById('resultadof')
    divResultado.innerHTML = "<div id='div2'><h1>Ex02</h1><label for='num2'>Digite um número:</label><input type='number' id='num2'><br><br><label for='num'>Digite um número para o inicio da tabuada:<label><input type='number' id='sta'><br><br><label for='num'>Digite um número para o fim da tabuada: </label><input type='number' id='end'> <br> <br><button onclick='Calcular1()'>Calcular</button><div id='resultado2'></div></div><script src='script.js'></script>"
}


function Ex3(){
    let divResultado = document.getElementById('resultadof')
    divResultado.innerHTML = "<div id='div1'><h1>Ex01</h1><label for='num'>Digite um número: </label><input type='number' id='num'><button onclick='Calcular()'>Calcular</button><div id='resultado1'></div></div><script src='script.js'></script>"
}

function Ex4(){
    let divResultado = document.getElementById('resultadof')
    divResultado.innerHTML = "<div id='div4'><h1>Ex04</h1><label for='val'>Digite o valor do carro: </label><input type='number' id='val'><br><br><button onclick='Calcular4()'>Calcular</button><div id='resultado4'></div></div><script src='script.js'></script>"
}

function Ex5(){
    let divResultado = document.getElementById('resultadof')
    divResultado.innerHTML = "<div id='div5'><h1>Ex05</h1><label for='num'>Digite um número: </label><input type='number' id='primo'> <br> <br><button onclick='Calcular5()'>Calcular</button><div id='resultado5'></div></div><script src='script.js'></script>"
}

function Ex6(){
    let divResultado = document.getElementById('resultadof')
    divResultado.innerHTML = "<div id='div6'><h1>Ex06</h1><label for='fim'>Digite um número</label><input type='number' id='fim'><button onclick='Calcular6()'>Calcular</button><div id='resultado6'></div></div><script src='scriptbase.js'></script><script src='script.js'></script>"
}

function Ex7(){
    let divResultado = document.getElementById('resultadof')
    divResultado.innerHTML = "<div id='div1'><h1>Ex01</h1><label for='num'>Digite um número: </label><input type='number' id='num'><button onclick='Calcular()'>Calcular</button><div id='resultado1'></div></div><script src='script.js'></script>"
}