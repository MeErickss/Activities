function Calcular(){
    let num = document.getElementById('num').value
    let divResultado = document.getElementById('resultado1')
    divResultado.innerHTML = ""
    let i = 0

    while (i<11){
        divResultado.innerHTML += "<p> TABUADA DO" + num + "<br>" + i + "*" + num + "=" + num*i + "</p>"
        i += 1
    }
}

function Calcular1(){
    let num = document.getElementById('num2').value
    let inicio = document.getElementById('sta').value
    let fim = document.getElementById('end').value
    let divResultado = document.getElementById('resultado2')
    divResultado.innerHTML = ""
    let i = 0

    while (i < inicio){
        i+=1
    }

    while (fim > i && i >= inicio){
        divResultado.innerHTML += "<p> TABUADA DO " + num + " de " + inicio + " até " + fim + "<br>" + i + "*" + num + "=" + num*i + "</p>"
        i+=1
    }


}

function Calcular4(){
    let valor = document.getElementById('val').value
    let divResultado = document.getElementById('resultado4')
    let vista = valor - (valor * 0.2) 
    let parc6 = valor + (valor * (0.3))
    let parc12 = valor + (valor * (0.6))
    let parc18 = valor + (valor * (0.9))

    divResultado.innerHTML = "<p> O valor do carro a vista é: " + vista + "<br><br>Já os valores parcelados são:<br> " + parc6 + " 6X<br>" + parc12 + " 12X<br>" + parc18 + " 18X<br></p>"
}

function Calcular5(){
    let num = document.getElementById('primo').value
    let divResultado = document.getElementById('resultado5')
    i = 3
    if (num == 2){
        return divResultado.innerHTML = "2<br><br>"
    }
    if (num == 3 ){
        return divResultado.innerHTML = "2 3<br><br>"
    }
    if (num < 2 ){
        return divResultado.innerHTML = ""
    }
    divResultado.innerHTML = "<p>" + 2 + "<br><br>" + 3 + "<br></p>"
    while (i < num){
        if (i % 2 != 0 && i % 3 != 0){
            divResultado.innerHTML += "<p>" + i + "</p>"
        }
        i+=1
    }
}

function Calcular6(){
    let numero = document.getElementById('fim').value
    let random = Math.random() * (numero - 1) + 1
    let divResultado = document.getElementById('resultado6')

    divResultado.innerHTML = "<p>O número sorteado entre 1 e " + numero + " foi " + random + "</p>"
}
