function calcular(){
    let inputLarg = document.getElementById('input_larg').value

    let inputProf = document.getElementById('input_prof').value

    let inputPrecmq = document.getElementById('input_pecmq').value

    let divMetroq = (inputLarg*inputProf)

    let divPreco = (divMetroq*inputPrecmq)

    let divResultado = document.getElementById('resultado')
    
    divResultado.innerHTML = "<h2>Tamanho do terreno: " + divMetroq + "</h2>" + "<br>" + "<h2>Preço do Terreno: " + divPreco + "</h2>"
}