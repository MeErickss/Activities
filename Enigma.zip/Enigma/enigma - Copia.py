print("Bem vindo!, esse é um enigma feito por mim :) (Erick) e para aquele que concluir ele eu tenho um prêmio, Boa sorte a todos\n")
n=str(input('Digite o seu nome: '))
i=input('Digite a sua idade: ')
y=13-int(i)
print(f'Nome: {n}\nIdade: {i}\n')
x=str(input(f"Começar?, {n} S/N\n"))
if x.lower()=='s' or x.lower()=='sim':
    x=input(f"Que número somado a {y} é =13?\n")
    while True:        
            if x==i:
                print(f"Sim!, sua idade :)\n Fácil, não? Então vamos começar o desafio :)")
                break
            else:
                print(f"Pense mais um pouco {n} :(")
                continue
    print("Eu, 67,6f,6c,70,65,28,6d,69,74,69,65,78,66,74,68,78,67,29 sou um grande fã de ......\n https://www.amazon.com.br/Uma-escada-para-Pollyana-Gama/dp/8579743702\n")
    while True:
        x=(input(f'Digite a resposta: '))
        if x.lower()=="led zeppelin":
            print(f"Parabéns, muito bem pensado")
            break
    print(f"SENHA TREML: NNACREDITO.Já joguei um jogo de um cara que migrou\nΧάος\n")
    while True:
        x=input('Digite a resposta: ')
        if x.lower()=="god of war":
            print(f"Parabéns, muito bem pensado")
            break
    print(f"SENHA FRAME E IMG:EITA, AVEBIXO.BFS3CFS3DF\n")
    while True:
        x=input('Digite a resposta: ')
        if x.lower()=="motor rotativo":
            print(f"Parabéns, muito bem pensado")
            break
    print(f"Aokigahara 03/01/2023yt\n")
    while True:
        x=input('Digite a resposta: ')
        if x.lower()=="baka gaijin":
            print(f"Parabéns, muito bem pensado")
            break
    print(f"Adoro Ulm, já li um jornal que comentava sobre ideias de alguém de lá\n62,75,72,61,63,6f,38.30.5 22.27.7\nhttps://www.amazon.com.br/Livros/b?ie=UTF8&node=6740748011\n")
    while True:
        x=input('Digite a resposta: ')
        if x.lower()=="buraco branco":
            print(f"Parabéns, muito bem pensado")
            break
    print(f"SENHA IMAGEM E NNSEI: TRABALHO, DIFICULDADE.Existe uma coroa pelas 3 e só há um rei")
    while True:
        x=input('Digite a resposta: ')
        if x.lower()=="graham hill":
            print(f"Parabéns, muito bem pensado")
            break
    print(f"QWtpaGFiYXJh Uma estrela #6f7270, descubra a senha do arquivo plau")
    while True:
        x=input('Digite a resposta: ')
        if x.lower()=="jojo":
            print(f"Parabéns, muito bem pensado")
            break
    print("Ele voou pela torre Eiffel com SEU dirigível 63,6d,39,74,59,51,3d,3d, use uma senha para o arquivo tcham e segredo")
    while True:
        x=input('Digite a resposta: ')
        if x.lower()=="divina comédia":
            print(f"Parabéns, muito bem pensado")
            break
    print(f"Do mesmo jeito que podemos SUCEDER, podemos VOLTAR aos antecessores, use o rar pasta pra resolver")
    while True:
        x=input('Digite a resposta: ')
        if x.lower()=="wu xing":
            print(f"Parabéns, você terminou o enigma, por enquanto.....")
            x=str(input('Fechar essa aba? S/N'))
            if x.lower()=='n':
                continue
            else:
                break
        break