function verificar(){
    let nome =  document.getElementById('name').value
    let gmail = document.getElementById('gmail').value
    let senha = document.getElementById('pass').value

    if (nome == "" || gmail == "" || senha == "" || senha.lenght <= 8){
        window.alert('Informações inválidas')
    } else{
        window.alert('Cadastro realizado')
        document.getElementById('name').value = null
        document.getElementById('gmail').value = null
        document.getElementById('pass').value = null
    }
}

function verificarL(){
    let gmail = document.getElementById('gmail').value
    let senha = document.getElementById('pass').value

    if (gmail == "" || senha == "" || senha.lenght <= 8 || gmail != "admin@email.com.br" || senha != "#dw1UTFPR#"){
        window.alert('Informações inválidas')
    } else{
        window.alert('Cadastro realizado')
        document.getElementById('gmail').value = null
        document.getElementById('pass').value = null
    }
}

function forgot(){
    return window.alert('Função ainda em desenvolvimento')
}